// NuevaSolicitudScreen.kt
package com.example.proyectolabdmoviles.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color

@Composable
fun NuevaSolicitudScreen(navController: NavController) {
    // Estados para los campos del formulario
    var producto by remember { mutableStateOf("") }
    var cantidad by remember { mutableStateOf("") }
    var comentario by remember { mutableStateOf("") }
    var urgencia by remember { mutableStateOf("") }
    var mostrarDropdownProducto by remember { mutableStateOf(false) }
    var mostrarDropdownUrgencia by remember { mutableStateOf(false) }

    // Listas de opciones
    val productos = listOf("Platos desechables", "Cubiertos", "Servilletas", "Vasos")
    val nivelesUrgencia = listOf("Baja", "Media", "Urgente")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // Título
        Text(
            text = "Nueva solicitud",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // --- Campo: Producto ---
        Text("Producto:", modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(
            value = producto,
            onValueChange = { producto = it },
            readOnly = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            trailingIcon = {
                IconButton(onClick = { mostrarDropdownProducto = true }) {
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Desplegar")
                }
            }
        )
        if (mostrarDropdownProducto) {
            AlertDialog(
                onDismissRequest = { mostrarDropdownProducto = false },
                title = { Text("Seleccione un producto") },
                text = {
                    Column {
                        productos.forEach { item ->
                            TextButton(
                                onClick = {
                                    producto = item
                                    mostrarDropdownProducto = false
                                }
                            ) {
                                Text(item)
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // --- Campo: Cantidad ---
        Text("Cantidad:", modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(
            value = cantidad,
            onValueChange = { cantidad = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            placeholder = { Text("Ej: 10") }
        )

        // --- Campo: Comentario (Opcional) ---
        Text("Comentario (opcional):", modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(
            value = comentario,
            onValueChange = { comentario = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            placeholder = { Text("Añada notas aquí") }
        )

        // --- Campo: Urgencia ---
        Text("Urgencia:", modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(
            value = urgencia,
            onValueChange = { urgencia = it },
            readOnly = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            trailingIcon = {
                IconButton(onClick = { mostrarDropdownUrgencia = true }) {
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Desplegar")
                }
            }
        )
        if (mostrarDropdownUrgencia) {
            AlertDialog(
                onDismissRequest = { mostrarDropdownUrgencia = false },
                title = { Text("Seleccione urgencia") },
                text = {
                    Column {
                        nivelesUrgencia.forEach { item ->
                            TextButton(
                                onClick = {
                                    urgencia = item
                                    mostrarDropdownUrgencia = false
                                }
                            ) {
                                Text(item)
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // --- Botones ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = { navController.popBackStack() },  // Cancelar: vuelve atrás
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
            ) {
                Text("Cancelar")
            }
            Button(
                onClick = {
                    // Lógica para enviar la solicitud (añadir luego)
                    navController.popBackStack()  // Temporal: vuelve atrás
                }
            ) {
                Text("Enviar")
            }
        }
    }
}