// AppNavigation.kt
package com.example.proyectolabdmoviles.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.proyectolabdmoviles.screens.AdminLoginScreen
import com.example.proyectolabdmoviles.screens.EmpleadoLoginScreen
import com.example.proyectolabdmoviles.screens.LoginScreen
import com.example.proyectolabdmoviles.screens.EmpleadoHomeScreen
import com.example.proyectolabdmoviles.screens.NuevaSolicitudScreen
import com.example.proyectolabdmoviles.screens.AdminHomeScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "login"
    ) {
        composable("login") { LoginScreen(navController) }
        composable("admin") { AdminLoginScreen(navController) }
        composable("empleado") { EmpleadoLoginScreen(navController) }
        composable("empleadoHome/{nombre}") { backStackEntry ->
            val nombre = backStackEntry.arguments?.getString("nombre") ?: "Empleado"
            EmpleadoHomeScreen(navController, nombre)
        }
        composable("nuevaSolicitud") { NuevaSolicitudScreen(navController) }
        composable("adminHome") {
            AdminHomeScreen(navController)
        }
    }
}