// AdminHomeScreen.kt
package com.example.proyectolabdmoviles.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun AdminHomeScreen(navController: NavController) {
    // Datos de ejemplo (luego puedes conectarlos a una base de datos)
    val productosCriticos = listOf(
        "Café (Quedan 5 unidades)",
        "Azúcar (Quedan 3 unidades)",
        "Leche (Quedan 2 unidades)"
    )

    val solicitudesPendientes = listOf(
        "Platos desechables - Urgente",
        "Servilletas - Media",
        "Cubiertos - Baja"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // --- Barra superior con botones ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Botón Inventario
            Button(
                onClick = { /* Navegar a gestión de inventario */ },
                modifier = Modifier.weight(1f)
            ) {
                Text("Inventario")
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Botón Empleados
            Button(
                onClick = { /* Navegar a gestión de empleados */ },
                modifier = Modifier.weight(1f)
            ) {
                Text("Empleados")
            }

            // Botón Notificaciones
            IconButton(
                onClick = { /* Mostrar notificaciones */ },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notificaciones"
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // --- Productos Críticos ---
        Text(
            text = "Productos críticos:",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            items(productosCriticos) { producto ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)  // Fondo rojo claro
                    )
                ) {
                    Text(
                        text = producto,
                        modifier = Modifier.padding(16.dp),
                        color = Color.Red
                    )
                }
            }
        }

        // --- Solicitudes Pendientes ---
        Text(
            text = "Solicitudes pendientes:",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth()
        ) {
            items(solicitudesPendientes) { solicitud ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Text(
                        text = solicitud,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}