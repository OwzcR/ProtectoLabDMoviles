// EmpleadoHomeScreen.kt
package com.example.proyectolabdmoviles.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun EmpleadoHomeScreen(navController: NavController, nombreEmpleado: String = "Usuario") {
    // Lista de ejemplo (puedes reemplazarla con datos reales luego)
    val inventario = listOf(
        "Elemento 1 - 50 unidades",
        "Elemento 2 - 30 unidades",
        "Elemento 3 - 15 unidades",
        "Elemento 4 - 80 unidades"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // Bienvenida
        Text(
            text = "Bienvenido, $nombreEmpleado",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Título inventario
        Text(
            text = "Inventario actual:",
            fontSize = 20.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Lista de inventario
        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(inventario) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = item,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }

        // Botón nueva solicitud
        Button(
            onClick = { navController.navigate("nuevaSolicitud") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Text("[+] Nueva solicitud", fontSize = 16.sp)
        }
    }
}