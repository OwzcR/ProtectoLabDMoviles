// LoginScreen.kt
package com.example.proyectolabdmoviles.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun LoginScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "INICIAR SESIÓN",
            fontSize = 24.sp,
            modifier = Modifier.padding(bottom = 40.dp)
        )
        Button(
            onClick = { navController.navigate("admin") },  // Navega a Admin
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6200EE)
            )
        ) {
            Text("ADMINISTRADOR")
        }
        Button(
            onClick = { navController.navigate("empleado") },  // Navega a Empleado
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF03DAC6)
            )
        ) {
            Text("EMPLEADO")
        }
    }
}